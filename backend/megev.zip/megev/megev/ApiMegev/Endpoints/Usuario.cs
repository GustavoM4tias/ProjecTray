﻿using megev.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Routing;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace megev.Endpoints
{
    public static class UsuariosEndpoints
    {
        public static void RegistrarEndpointsUsuarios(this IEndpointRouteBuilder rotas)
        {
            // Grupamento de rotas
            var rotaUsuarios = rotas.MapGroup("/usuarios");

            // GET      /usuarios
            rotaUsuarios.MapGet("/", async (MegevDbContext dbContext, string? nome, string? sobrenome) =>
            {
                IQueryable<Usuario> usuariosFiltrados = dbContext.Usuario;

                if (!string.IsNullOrEmpty(nome))
                {
                    usuariosFiltrados = usuariosFiltrados.Where(u => u.Nome.Contains(nome));
                }

                if (!string.IsNullOrEmpty(sobrenome))
                {
                    usuariosFiltrados = usuariosFiltrados.Where(u => u.Sobrenome.Contains(sobrenome));
                }

                return TypedResults.Ok(await usuariosFiltrados.ToListAsync());
            });

            // GET      /usuarios/{id}
            rotaUsuarios.MapGet("/{id}", async (MegevDbContext dbContext, int id) =>
            {
                Usuario? usuario = await dbContext.Usuario.FindAsync(id);
                if (usuario is null)
                {
                    return Results.NotFound();
                }

                return TypedResults.Ok(usuario);
            }).Produces<Usuario>();

            // POST     /usuarios
            rotaUsuarios.MapPost("/", async (MegevDbContext dbContext, Usuario usuario) =>
            {
                dbContext.Usuario.Add(usuario);
                await dbContext.SaveChangesAsync();

                return TypedResults.Created($"/usuarios/{usuario.Id}", usuario);
            });

            // PUT      /usuarios/{id}
            rotaUsuarios.MapPut("/{id}", async (MegevDbContext dbContext, int id, Usuario usuario) =>
            {
                Usuario? usuarioEncontrado = await dbContext.Usuario.FindAsync(id);
                if (usuarioEncontrado is null)
                {
                    return Results.NotFound();
                }

                usuario.Id = id;
                dbContext.Entry(usuarioEncontrado).CurrentValues.SetValues(usuario);
                await dbContext.SaveChangesAsync();

                return TypedResults.NoContent();
            });

            // DELETE   /usuarios/{id}
            rotaUsuarios.MapDelete("/{id}", async (MegevDbContext dbContext, int id) =>
            {
                Usuario? usuarioEncontrado = await dbContext.Usuario.FindAsync(id);
                if (usuarioEncontrado is null)
                {
                    return Results.NotFound();
                }

                dbContext.Usuario.Remove(usuarioEncontrado);
                await dbContext.SaveChangesAsync();

                return TypedResults.NoContent();
            });
        }
    }
}

using megev;
using megev.Endpoints;

namespace megev
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // Cria��o da WebApplication
            var builder = WebApplication.CreateBuilder(args);

            // Configura��o do Swagger
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddCors(
                b => b.AddDefaultPolicy(c => c
                .AllowAnyMethod()
                .AllowAnyOrigin()
                .AllowAnyHeader())
                );

            builder.Services.AddDbContext<MegevDbContext>();

            // Constru��o da WebApplication
            var app = builder.Build();

            if (app.Environment.IsDevelopment())
            {
                // Inicializa��o do Swagger
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.RegistrarEndpointsUsuarios();
            app.RegistrarEndpointsProdutos();
            app.RegistrarEndpointsMetodoPagamento();
            app.RegistrarEndpointsMetodosEntrega();
            app.RegistrarEndpointsObjetivoLoja();
            app.RegistrarEndpointsLoja();
            app.RegistrarEndpointsCategoriaProduto();

            app.UseCors();

            // Execu��o da aplica��o
            app.Run();
        }
    }
}

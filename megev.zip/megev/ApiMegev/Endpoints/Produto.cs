﻿using megev.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace megev.Endpoints
{
    public static class ProdutoEndpoints
    {
        public static void RegistrarEndpointsProdutos(this IEndpointRouteBuilder rotas)
        {
            var rotaProdutos = rotas.MapGroup("/produtos");

            rotaProdutos.MapGet("/", async (MegevDbContext dbContext) =>
            {
                var produtos = await dbContext.Produto.ToListAsync();
                return TypedResults.Ok(produtos);
            });

            rotaProdutos.MapGet("/{id}", async (MegevDbContext dbContext, int id) =>
            {
                var produto = await dbContext.Produto.FindAsync(id);
                if (produto == null)
                    return Results.NotFound();

                return TypedResults.Ok(produto);
            }).Produces<Produto>();

            rotaProdutos.MapPost("/", async (MegevDbContext dbContext, Produto produto) =>
            {
                dbContext.Produto.Add(produto);
                await dbContext.SaveChangesAsync();

                return TypedResults.Created($"/produtos/{produto.Id}", produto);
            });

            rotaProdutos.MapPut("/{id}", async (MegevDbContext dbContext, int id, Produto produto) =>
            {
                var produtoExistente = await dbContext.Produto.FindAsync(id);
                if (produtoExistente == null)
                    return Results.NotFound();

                produto.Id = id;
                dbContext.Entry(produtoExistente).CurrentValues.SetValues(produto);
                await dbContext.SaveChangesAsync();

                return TypedResults.NoContent();
            });

            rotaProdutos.MapDelete("/{id}", async (MegevDbContext dbContext, int id) =>
            {
                var produtoExistente = await dbContext.Produto.FindAsync(id);
                if (produtoExistente == null)
                    return Results.NotFound();

                dbContext.Produto.Remove(produtoExistente);
                await dbContext.SaveChangesAsync();

                return TypedResults.NoContent();
            });
        }
    }
}

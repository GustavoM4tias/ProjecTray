﻿using megev.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace megev.Endpoints
{
    public static class MetodosEntregaEndpoints
    {
        public static void RegistrarEndpointsMetodosEntrega(this IEndpointRouteBuilder rotas)
        {
            var rotaMetodosEntrega = rotas.MapGroup("/metodos-entrega");

            rotaMetodosEntrega.MapGet("/", async (MegevDbContext dbContext) =>
            {
                var metodosEntrega = await dbContext.MetodosEntrega.ToListAsync();
                return TypedResults.Ok(metodosEntrega);
            });

            rotaMetodosEntrega.MapGet("/{id}", async (MegevDbContext dbContext, int id) =>
            {
                var metodoEntrega = await dbContext.MetodosEntrega.FindAsync(id);
                if (metodoEntrega == null)
                    return Results.NotFound();

                return TypedResults.Ok(metodoEntrega);
            }).Produces<MetodosEntrega>();

            rotaMetodosEntrega.MapPost("/", async (MegevDbContext dbContext, MetodosEntrega metodoEntrega) =>
            {
                dbContext.MetodosEntrega.Add(metodoEntrega);
                await dbContext.SaveChangesAsync();

                return TypedResults.Created($"/metodos-entrega/{metodoEntrega.Id}", metodoEntrega);
            });

            rotaMetodosEntrega.MapPut("/{id}", async (MegevDbContext dbContext, int id, MetodosEntrega metodoEntrega) =>
            {
                var metodoEntregaExistente = await dbContext.MetodosEntrega.FindAsync(id);
                if (metodoEntregaExistente == null)
                    return Results.NotFound();

                metodoEntrega.Id = id;
                dbContext.Entry(metodoEntregaExistente).CurrentValues.SetValues(metodoEntrega);
                await dbContext.SaveChangesAsync();

                return TypedResults.NoContent();
            });

            rotaMetodosEntrega.MapDelete("/{id}", async (MegevDbContext dbContext, int id) =>
            {
                var metodoEntregaExistente = await dbContext.MetodosEntrega.FindAsync(id);
                if (metodoEntregaExistente == null)
                    return Results.NotFound();

                dbContext.MetodosEntrega.Remove(metodoEntregaExistente);
                await dbContext.SaveChangesAsync();

                return TypedResults.NoContent();
            });
        }
    }
}
